
package threading;

import java.awt.Color;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class Threading implements MouseMotionListener{
    private JFrame frame;
    private JPanel panel;
    
    public void init()
    {
        frame = new JFrame("Panel Movement");
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setSize(500,500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   
        panel = new JPanel();
        panel.setSize(100,100);
        panel.setBackground(Color.red);
        panel.setBounds(10,10,30,30);
        
        frame.add(panel);
        
        frame.addMouseMotionListener(this);
    }
    public static void main(String[] args) {
        Threading td = new Threading();
        td.init();
    }

   
    @Override
    public void mouseDragged(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        panel.setBounds(e.getX(), e.getY(), e.getX(), e.getY());
    }

    
}
