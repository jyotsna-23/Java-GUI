
package registration;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.border.Border;
public class Registration extends JFrame  implements ActionListener{
    JLabel lb1,lb2,lb3,lb4,lb5,lb6,lb7,lb8,lb9, lb10;
    JPanel pan,pan1,pan2;
    JTextField txt1,txt2,txt3,txt4;
    JTextArea txt5;
    JComboBox city,state,country;
    JButton btn1,btn2,btn3;
    JDialog dia1;
 
    public void init()
    {
   
        setTitle("Registration Form");
        setSize(800,1000);
        setLayout(null);
        
        
        pan = new JPanel();
        pan1 = new JPanel();
        pan2 = new JPanel();
        pan.setLayout(null);
        pan1.setLayout(null);
        
        lb1 = new JLabel("Registration Form");
        lb2 = new JLabel("First name:");
        lb3 = new JLabel("Last name:");
        lb4 = new JLabel("Phone number:");
        lb5 = new JLabel("Email Address:");
        lb6 = new JLabel("Address:");
        lb7 = new JLabel("city:");
        lb8 = new JLabel("State:");
        lb9 = new JLabel("Country:");
        lb10 = new JLabel("Successfully Registered");
        
        txt1 = new JTextField();
        txt2 = new JTextField();
        txt3 = new JTextField();
        txt4 = new JTextField();
        
        txt5 = new JTextArea();
        
        String city_names[] = new String[]{" ","Faridabad","Noida","Gurugram","Mangolore","Bangolore"};
        String State_names[] = new String[]{" ","Delhi","Haryana","Karnataka","Mumbai"};
        String country_names[] = new String[]{" ","India","USA","France"};
        
        city = new JComboBox(city_names);
        state = new JComboBox(State_names);
        country = new JComboBox(country_names);
        
        btn1 = new JButton("Register");
        btn2 = new JButton("Clear");
        btn3 = new JButton("Close");
        
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        
        dia1 = new JDialog();
       
    }
    
    public void setup()
    {
        init();
        add(pan);
        add(pan1);
        
        Font f = new Font("TimesRoman", Font.BOLD, 45);
        Font f1 = new Font("TimesRoman", Font.BOLD, 30);
        Font f2 = new Font("TimesRoman", Font.BOLD, 22);
        lb1.setForeground(Color.red);
        lb1.setFont(f);
        lb2.setForeground(Color.black);
        lb2.setFont(f1);
        lb3.setForeground(Color.black);
        lb3.setFont(f1);
        lb4.setForeground(Color.black);
        lb4.setFont(f1);
        lb5.setForeground(Color.black);
        lb5.setFont(f1);
        lb6.setForeground(Color.black);
        lb6.setFont(f1);
        lb7.setForeground(Color.black);
        lb7.setFont(f1);
        lb8.setForeground(Color.black);
        lb8.setFont(f1);
        lb9.setForeground(Color.black);
        lb9.setFont(f1);
        lb10.setForeground(Color.red);
        lb10.setFont(f1);
        txt1.setFont(f2);
        txt2.setFont(f2);
        txt3.setFont(f2);
        txt4.setFont(f2);
        txt5.setFont(f2);
        city.setFont(f2);
        state.setFont(f2);
        country.setFont(f2);
        btn1.setFont(f2);
        btn2.setFont(f2);
        btn3.setFont(f2);
        
        btn1.setBackground(Color.red);
        btn1.setForeground(Color.white);
        btn2.setBackground(Color.red);
        btn2.setForeground(Color.white);
        
        Border border = BorderFactory.createLineBorder(Color.black);
        txt5.setBorder(border);
       
        pan.setBackground(Color.red);
        pan.setBounds(0, 0, 778, 945);
        pan2.setBackground(Color.white);
        pan.add(pan1);
        pan1.add(lb1);
        pan1.add(lb2);
        pan1.add(lb3);
        pan1.add(lb4);
        pan1.add(lb5);
        pan1.add(lb6);
        pan1.add(lb7);
        pan1.add(lb8);
        pan1.add(lb9);
        pan1.add(txt1);
        pan1.add(txt2);
        pan1.add(txt3);
        pan1.add(txt4);
        pan1.add(txt5);
        pan1.add(city);
        pan1.add(state);
        pan1.add(country);
        pan1.add(lb10);
        pan1.add(btn1);
        pan1.add(btn2);
        pan1.setBackground(Color.white);
        pan1.setBounds(5,5,767,935);
        
        
        lb1.setBounds(20,25, 600, 55);
        lb2.setBounds(20,120, 600, 55);
        txt1.setBounds(20,176, 300, 35);
        lb3.setBounds(440,120, 600, 55);
        txt2.setBounds(440,176, 300, 35);
        lb4.setBounds(20,230, 600, 55);
        txt3.setBounds(20,290, 300, 35);
        lb5.setBounds(20,340, 600, 55);
        txt4.setBounds(20,390, 300, 35);
        lb6.setBounds(20,430, 600, 55);
        txt5.setBounds(20,490, 300, 45);
        lb7.setBounds(20,530, 600, 55);
        city.setBounds(20,590, 300, 35);
        lb8.setBounds(20,630, 600, 55);
        state.setBounds(20,690, 300, 35);
        lb9.setBounds(20,730, 600, 55);
        
        country.setBounds(20,790, 300, 35);
        btn1.setBounds(110,850, 200, 65);
        btn2.setBounds(440,850, 200, 65);
       
        setVisible(true); 
        setDefaultCloseOperation(EXIT_ON_CLOSE);
   
    }
    

    public static void main(String[] args) {
        Registration res = new Registration();
        res.setup();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch(e.getActionCommand())
        {
            case "Register": 
                
                File f = new File("C:\\Users\\user\\Desktop\\Registeration.txt");
                        String a = new String();
                     try(BufferedWriter bw = new BufferedWriter(new FileWriter(f, true))){
                         StringBuffer sb = new StringBuffer();
                         sb.append("\r\n");
                         sb.append("First Name : "+txt1.getText());
                         sb.append("\r\n");
                         sb.append("Second Name :"+txt2.getText());
                         sb.append("\r\n");
                         sb.append("Phone No. :"+txt3.getText());
                         sb.append("\r\n");
                         sb.append("Email :"+txt4.getText());
                         sb.append("\r\n");
                         sb.append("Address :"+txt5.getText());
                         sb.append("\r\n");
                         sb.append("City :"+city.getSelectedItem().toString());
                         sb.append("\r\n");
                         sb.append("State :"+state.getSelectedItem().toString());
                         sb.append("\r\n");
                         sb.append("Country :"+country.getSelectedItem().toString());
                         sb.append("\r\n");
                         
                         bw.write(sb.toString());
                    dia1.add(pan2);
                    pan2.setLayout(null);
                    lb10.setBounds(60,30,400,40);
                    pan2.add(lb10);
                    dia1.setSize(500,200);
                    dia1.setVisible(true);
                     }catch(IOException exp){
                         System.out.println(exp);
                     }         
                break;
            case "Clear": txt1.setText(" ");
                          txt2.setText(" ");
                          txt3.setText(" ");
                          txt4.setText(" ");
                          txt5.setText(" ");
                          city.setSelectedIndex(0);
                          state.setSelectedIndex(0);
                          country.setSelectedIndex(0);
                          break;
            
        }
    }
    
}
