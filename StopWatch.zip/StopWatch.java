
package stopwatch;


import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class StopWatch extends Thread implements ActionListener{
    JFrame frame;
    JLabel txt1;
    JButton btn1,btn2,btn3;
    static StopWatch sw = new StopWatch();
    public StopWatch()
    {
        frame = new JFrame("Stop Watch");
        
        btn1 = new JButton("Start");
        btn2 = new JButton("Stop");
        btn3 = new JButton("Reset");
        txt1 = new JLabel("");
        frame.setSize(400,300);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        
        frame.add(txt1);
        frame.add(btn1);
        frame.add(btn2);
        frame.add(btn3);
        
        Font f = new Font("TimesRoman",Font.BOLD,23);
        
        txt1.setBounds(150,40,50,50);
        txt1.setFont(f);
        btn1.setBounds(60,100,70,30);
        btn2.setBounds(140,100,70,30);
        btn3.setBounds(220,100,70,30);
        
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        btn3.addActionListener(this);
     
    }
    public void run()
    {
        try{
            for(int i=60; i>=0;i--)
            {
              txt1.setText(" "+i);
              Thread.sleep(1000);
            }
            txt1.setText("Times Up");
        }
        catch(InterruptedException exp)
        {
           System.err.println(exp);
        }
    }
    public void actionPerformed(ActionEvent e) {
        switch(e.getActionCommand())
        {
            case "Start": sw.start();
                break;
            case "Stop":
                sw.stop();
                break;
            case "Reset": int i=0;
                txt1.setText(""+i);
                
        }
        
    }
    public static void main (String args[])
    {
        StopWatch sw =  StopWatch.sw;
        
    }
    
}
